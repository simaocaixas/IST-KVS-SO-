This folder contains a possible solution of the first part of the project, which can be used as starting point for developing the second part. This option is recommended especially if the solution that you developed for the first part of the project is known to suffer of issues. Yet, you can opt for developing the second part of the project by extending your own solution to the first part of the project.

Note that the synchronisation logic used by this solution is intentionally simple (based on a single Read-Write lock) in order to serve as an easy to comprehend starting point for the second part of the project.




